-- Group 04
-- Damian Franco & Trey Sampson

INSERT INTO OMI_CASE
VALUES (123, TO_DATE('2022-01-02','YYYY-MM-DD'), TO_DATE('2022-02-01','YYYY-MM-DD'), 
        'JIM', 'J', 'JOHNSON', TO_DATE('1966-06-06','YYYY-MM-DD'), '123456789', 6, 1, 
        'Male', 'White', 123, 'Main St.', '87123', 'ABQ', 'Bernalillo', 'Forest',
        0, 1, 1, 1, 'Modern', 'Yes', 'NW', 1);

INSERT INTO OMI_CASE
VALUES (124, TO_DATE('2022-01-03','YYYY-MM-DD'), TO_DATE('2021-02-01','YYYY-MM-DD'),
        'JANE', 'J', 'JOHNSON', TO_DATE('1965-05-06','YYYY-MM-DD'), '123455555', 5, 5,
        'Female', 'White', 123, 'Main St.', '87123', 'ABQ', 'Bernalillo', 'Forest',
        0, 1, 1, 1, 'Modern', 'Yes', 'NW', 1);

INSERT INTO OMI_CASE
VALUES (125, TO_DATE('2021-06-04','YYYY-MM-DD'), TO_DATE('2022-03-01','YYYY-MM-DD'),
        'JOE', 'R', 'JAMESON', TO_DATE('1963-06-06','YYYY-MM-DD'), '123456123', 6, 1,
        'Male','White', 123, 'Main St.', '87123', 'ABQ', 'Bernalillo', 'Apartment', 
        1, 0, 1, 1, 'Modern', 'Yes', 'NW', 1);