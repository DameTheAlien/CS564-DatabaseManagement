-- Group 04
-- Damian Franco & Trey Sampson

INSERT INTO BONE
VALUES (1001, 123, 3, 'Inches', 'White', 7, 1, 1, 1, 'Radiocarbon', 1);

INSERT INTO LIMB
VALUES (1001, 'Right extremity');

INSERT INTO LEG
VALUES (1001, 'Right leg');

INSERT INTO FOOT
VALUES (1001, 'Right big toe');

INSERT INTO BONE
VALUES (1002, 124, 1, 'Pound', 'Grey', 7, 1, 1, 1, 'Radiocarbon', 0);

INSERT INTO LIMB
VALUES (1002, 'Left extremity');

INSERT INTO LEG
VALUES (1002, 'Left leg');

INSERT INTO THIGH
VALUES (1002, 'Left femur');

INSERT INTO BONE
VALUES (1003, 125, 2, 'Pound', 'White', 8, 1, 1, 1, 'Radiocarbon', 1);

INSERT INTO HEAD
VALUES (1003, 'Partial Skull');

INSERT INTO SKULL
VALUES (1003, 'Missing mandible');